#include "CurrentSorceTrans.h"

#define SENSOR1 1
#define SENSOR2 3
#define TEMPSENSOR 2


#ifndef SENSOR_PH_EC
	uint16_t High_PPm_AD = 2;  
	uint16_t Low_PPm_AD  = 0;
	
	uint16_t  High_NTU_AD = 10;
	uint16_t  Low_NTU_AD = 0;
#else
	uint16_t High_PPm_AD = 14;  
	uint16_t Low_PPm_AD  = 0;
	
	uint16_t  High_NTU_AD = 2000;
	uint16_t  Low_NTU_AD = 0;
#endif





uint16_t High_TempD = 60; 
uint16_t Low_TempD  = 0;

uint16_t High_Current = 20;  
uint16_t Low_Current  = 4;

float Senosr1Slope = 0.0;
float Senosr1Offset = 0.0;

float Current1Slope = 0.0;
float Current11Offset = 0.0;

float Senosr2Slope = 0.0;
float Senosr2Offset = 0.0;

float Current2Slope = 0.0;
float Current21Offset = 0.0;

float Temp_Slope = 0.0;
float Temp_Offset = 0.0;

uint16_t compare_vaule_20mA = 5000;  //5000; BY JU
uint16_t compare_vaule_4mA  = 0;   //600  100;

uint16_t compare_vaule_20mA2 = 5000;  //5000; BY JU
uint16_t compare_vaule_4mA2  = 0;   //600  100;

uint16_t final_OutPut_vaule = 0;
uint16_t trans_anlog_pwmVaule  = 0;
uint16_t trans_anlog_pwmVaule2 = 0;
uint16_t trans_temp_pwmVaule = 0;

uint16_t Lowpwm = 0;
uint16_t Highpwm = 0;
uint16_t LowCurrentpwm = 0;
uint16_t HighCurrentpwm = 0;


// 12-4.0
// 13=4.05
// 14-4.16
// 15-4.27
// 16-4.37
// 17- 4.44
// 18-4.54
// 19-4.63
// 20-4.7

//30 - 5.55
//40-5.8

// 100-11.6
// 150-15.8
// 180-18.45
// 190-19.28
// 195-19.73
// 197-19.85


/*
// index �� ppm �̴�. 20230308
const unsigned int DAC_4_20MA[201] = 
{554, 581, 608, 636, 663, 690, 723, 756, 789, 822,
 855, 908, 961,1014,1067,1120,1135,1149,1178,1207,
1236,1260,1284,1309,1333,1357,1382,1407,1433,1458,
1483,1508,1533,1559,1584,1607,1631,1656,1680,1705,
1729,1753,1778,1802,1827,1851,1875,1900,1924,1949,

1973,1997,2022,2046,2071,2095,2119,2144,2168,2193,
2217,2240,2263,2286,2309,2333,2355,2377,2399,2421,
2443,2466,2489,2512,2535,2556,2580,2604,2628,2652,
2678,2702,2726,2750,2774,2800,2825,2850,2875,2900,
2923,2947,2971,2995,3019,3045,3070,3095,3120,3145,

3168,3193,3218,3243,3268,3294,3322,3350,3378,3406,
3434,3459,3484,3509,3534,3559,3581,3603,3625,3647,
3668,3689,3710,3731,3752,3774,3793,3812,3831,3850,
3869,3888,3907,3926,3945,3965,3984,4003,4022,4041,
4060,4079,4098,4117,4136,4157,4177,4197,4217,4237,

4258,4277,4296,4315,4334,4354,4370,4386,4402,4418,
4436,4457,4478,4499,4520,4539,4560,4581,4602,4623,
4642,4663,4684,4705,4726,4745,4766,4787,4808,4829,
4848,4869,4890,4911,4932,4951,4971,4991,5011,5031,
5050,5070,5090,5110,5130,5150,5168,5186,5204,5222,
5242 };

// NTU ������, 20230427  
const unsigned int TABLE_4_20MA2[1001] = 
{554,559,565,570,576,581,587,592,598,603,
608,614,619,625,630,636,641,646,652,657,
663,668,674,679,685,690,697,703,710,716,
723,730,736,743,749,756,763,769,776,782,
789,796,802,809,815,822,829,835,842,848,
855,866,876,887,897,908,919,929,940,950,
961,972,982,993,1003,1014,1025,1035,1046,1056,
1067,1078,1088,1099,1109,1120,1127,1134,1141,1148,
1155,1162,1169,1176,1183,1190,1197,1204,1211,1218,
1225,1232,1239,1246,1253,1260,1267,1274,1281,1288,
1295,1300,1305,1310,1315,1320,1325,1330,1335,1340,
1345,1350,1355,1360,1365,1370,1375,1380,1385,1390,
1395,1400,1405,1410,1415,1420,1425,1430,1435,1440,
1445,1450,1455,1460,1465,1470,1475,1480,1485,1490,
1495,1500,1505,1510,1515,1520,1525,1530,1535,1540,
1545,1550,1555,1560,1565,1570,1574,1579,1584,1589,
1594,1599,1604,1609,1614,1619,1623,1628,1633,1638,
1643,1648,1653,1658,1663,1668,1672,1677,1682,1687,
1692,1697,1702,1707,1712,1717,1721,1726,1731,1736,
1741,1746,1751,1756,1761,1766,1770,1775,1780,1785,
1790,1795,1800,1805,1810,1815,1819,1824,1829,1834,
1839,1844,1849,1854,1859,1864,1868,1873,1878,1883,
1888,1893,1898,1903,1908,1913,1917,1922,1927,1932,
1937,1942,1947,1952,1957,1962,1966,1971,1976,1981,
1986,1991,1996,2001,2006,2011,2015,2020,2025,2030,
2035,2040,2045,2050,2055,2060,2064,2069,2074,2079,
2084,2089,2094,2099,2104,2109,2113,2118,2123,2128,
2133,2138,2143,2148,2153,2158,2162,2167,2172,2177,
2182,2187,2192,2197,2202,2207,2211,2216,2221,2226,
2231,2236,2241,2246,2251,2256,2260,2265,2270,2275,
2280,2285,2290,2295,2300,2305,2309,2314,2319,2324,
2329,2334,2339,2344,2349,2354,2358,2363,2368,2373,
2378,2383,2388,2393,2398,2403,2407,2412,2417,2422,
2427,2432,2437,2442,2447,2452,2456,2461,2466,2471,
2476,2481,2486,2491,2496,2501,2505,2510,2515,2520,
2525,2530,2535,2540,2545,2550,2554,2559,2564,2569,
2574,2579,2584,2589,2594,2599,2603,2608,2613,2618,
2623,2628,2633,2638,2643,2648,2652,2657,2662,2667,
2672,2677,2682,2687,2692,2697,2701,2706,2711,2716,
2721,2726,2731,2736,2741,2746,2750,2755,2760,2765,
2770,2775,2780,2785,2790,2795,2799,2804,2809,2814,
2819,2824,2829,2834,2839,2844,2848,2853,2858,2863,
2868,2873,2878,2883,2888,2893,2897,2902,2907,2912,
2917,2922,2927,2932,2937,2942,2946,2951,2956,2961,
2966,2971,2976,2981,2986,2991,2995,3000,3005,3010,
3015,3020,3025,3030,3035,3040,3044,3049,3054,3059,
3064,3069,3074,3079,3084,3089,3093,3098,3103,3108,
3113,3118,3123,3128,3133,3138,3142,3147,3152,3157,
3162,3167,3172,3177,3182,3187,3191,3196,3201,3206,
3211,3216,3221,3226,3231,3236,3240,3245,3250,3255,
3260,3265,3270,3275,3280,3285,3289,3294,3299,3304,
3309,3314,3319,3324,3329,3334,3338,3343,3348,3353,
3358,3363,3368,3373,3378,3383,3387,3392,3397,3402,
3407,3412,3417,3422,3427,3432,3436,3441,3446,3451,
3456,3461,3466,3471,3476,3481,3485,3490,3495,3500,
3505,3510,3515,3520,3525,3530,3534,3539,3544,3549,
3554,3559,3564,3569,3574,3579,3583,3588,3593,3598,
3603,3608,3613,3618,3623,3628,3632,3637,3642,3647,
3652,3657,3662,3667,3672,3677,3681,3686,3691,3696,
3701,3706,3711,3716,3721,3726,3730,3735,3740,3745,
3750,3754,3758,3762,3766,3770,3774,3778,3782,3786,
3790,3794,3798,3802,3806,3810,3814,3818,3822,3826,
3830,3834,3838,3842,3846,3850,3854,3857,3861,3865,
3868,3872,3875,3879,3883,3886,3890,3894,3897,3901,
3905,3908,3912,3916,3919,3923,3926,3930,3934,3937,
3941,3945,3949,3953,3957,3960,3964,3968,3972,3976,
3980,3984,3988,3991,3995,3999,4003,4007,4011,4015,
4019,4022,4026,4030,4034,4038,4042,4045,4049,4053,
4056,4060,4064,4067,4071,4075,4078,4082,4086,4090,
4093,4097,4101,4104,4108,4112,4115,4119,4123,4126,
4130,4134,4138,4142,4146,4150,4154,4158,4162,4166,
4170,4174,4178,4182,4186,4190,4194,4198,4202,4206,
4210,4214,4218,4222,4226,4230,4234,4238,4242,4246,
4251,4255,4259,4263,4267,4271,4275,4279,4284,4288,
4292,4296,4300,4304,4308,4312,4316,4321,4325,4329,
4333,4337,4341,4345,4349,4354,4358,4362,4366,4370,
4374,4378,4382,4386,4391,4395,4399,4403,4407,4411,
4415,4419,4424,4428,4432,4436,4440,4444,4448,4452,
4456,4461,4465,4469,4473,4477,4481,4485,4489,4494,
4498,4502,4506,4510,4514,4518,4522,4526,4531,4535,
4539,4543,4547,4551,4555,
4559,4564,4568,4572,4576,4580,4584,4588,4592,4596,
4601,4605,4609,4613,4617,4621,4625,4629,4634,4638,
4642,4646,4650,4654,4658,4662,4666,4671,4675,4679,
4683,4687,4691,4695,4699,4704,4708,4712,4716,4720,
4724,4728,4732,4736,4741,4745,4749,4753,4757,4761,
4765,4769,4774,4778,4782,4786,4790,4794,4798,4802,
4806,4811,4815,4819,4823,4827,4831,4835,4839,4844,
4848,4852,4856,4860,4864,4868,4872,4876,4881,4885,
4889,4893,4897,4901,4905,4909,4914,4918,4922,4926,
4930,4934,4938,4942,4946,4951,4955,4959,4963,4967,
4971,4975,4979,4984,4988,4992,4996,5000,5004,5008,
5012,5016,5021,5025,5029,5033,5037,5041,5045,5049,
5054,5057,5061,5065,5069,5073,5077,5081,5084,5088,
5092,5096,5100,5104,5108,5111,5115,5119,5123,5127,
5131,5135,5138,5142,5146,5150,5154,5157,5161,5165,
5168,5172,5176,5179,5183,5187,5190,5194,5198,5202,
5205,5209,5213,5216,5220,5224,5227,5231,5235,5238,
5242,5246,5249,5253,5256,5260,5263,5267,5270,5274,
5277,5281,5284,5288,5291,5295,5298,5302,5305,5309,
5312,5316,5319,5323,5326,5330 };
*/


  /*
// index �� ppm �̴�. 20230902
const unsigned int DAC_4_20MA[34] = 
{   
1125,1150,1200,1250,1300,1350,1400,1450,1500,1550,
1600,1650,1700,1750,1800,1850,1900,1950,2000,2050,
2100,2150,2200,2250,2300,2350,2400,2450,2500,2550,
2600,2650,2700,2710 };

const unsigned int TABLE_4_20MA_100[34] = 
{
400,410,433,458,486, 516,549,585,622,661,
703,747,792,841,890, 941,993,1048,1101,1157,
1216,1276,1337,1399,1463, 1527,1591,1656,1721,1788,
1854,1921,1988,2000 };
  
*/

 
  /*
// index �� ppm �̴�. 20230308
const unsigned int DAC_4_20MA[34] = 
{   
1120,1150,1200,1250,1300, 1350,1400,1450,1500,1550,
1600,1650,1700,1750,1800, 1850,1900,1950,2000,2050,
2100,2150,2200,2250,2300, 2350,2400,2450,2500,2550,
2600,2650,2675,2680 };


const unsigned int TABLE_4_20MA_100[34] = 
{
400,411,435,461,490, 522,556,593,632,673,
716,762,810,859,911, 965,1020,1078,1137,1196,
1256,1317,1379,1441,1505, 1571,1638,1704,1772,1840,
1907,1972,2000, 2005 };
*/

	
  /*
// index �� ppm �̴�. 20230902
const unsigned int DAC_4_20MA[34] = 
{   
1091,1120,1169,1217,1266, 1315,1363,1412,1461,1509,
1558,1607,1656,1704,1753, 1802,1850,1899,1948,1996,
2045,2094,2142,2191,2240, 2289,2337,2386,2435,2483,
2532,2581,2605, 2615 };

const unsigned int TABLE_4_20MA_100[34] = 
{
400,411,435,461,490, 522,556,593,632,673,
716,762,810,859,911, 965,1020,1078,1137,1196,
1256,1317,1379,1441,1505, 1571,1638,1704,1772,1840,
1907,1972,2000, 2005 };
*/
  
	   
// index �� ppm �̴�. 20230902
const unsigned int DAC_4_20MA[34] = 
{   
1106,1150,1200,1250,1300, 1350,1400,1450,1500,1550,
1600,1650,1700,1750,1800, 1850,1900,1950,2000,2050,
2100,2150,2200,2250,2300, 2350,2400,2450,2500,2550,
2600,2650,2675, 2695 };


const unsigned int TABLE_4_20MA_100[34] = 
{
400,448,503,558,612, 667,722,776,831,886,
941,995,1050,1105,1160, 1214,1269,1324,1378,1433,
1488,1543,1597,1652,1707, 1761,1816,1871,1926, 1980,
2035,2090,2117, 2140 };
	 




		  /*
const float PPM[15] = 
{
0,
0.1,
0.2,
0.5,
0.6,
0.7,
0.9,
1,
1.1,
1.5,
1.6,
1.7,
1.79,
1.9,
2
};


const float PPM_4_20MA[15] = {
3.997,
4.826,
5.647,
8.126,
8.955,
9.782,
11.433,
12.265,
13.093,
16.398,
17.226,
18.053,
18.895,
20.144,
21.335
};



const float PWM_4_20MA[15] =  {
1140,
1395,
1647,
2405,
2671,
2911,
3417,
3671,
/3923,
4936,
5188,
5440,
5668,
5946,
5987
};		*/


/*
const float PPM_4_20MA[33] = {
4,4.5,5,5.5,6, 6.5,7,7.5,8,8.5,
9,9.5,10,10.5,11, 11.5,12,12.5,13,13.5,
14,14.5,15,15.5,16, 16.5,17,17.5,18,18.5,
19,19.5,20	 };
  */

/*
const float PWM_4_20MA[33] =  {
1116,
1268,
1419,
1571,
1723,
1875,
2026,
2178,
2330,
2482,
2633,
2785,
2937,
3091,
3246,
3402,
3561,
3703,
3856,
4008,
4160,
4313,
4465,
4617,
4770,
4922,
5075,
5227,
5379,
5532,
5684,
5836,
5989
 };

 */
		 /*
const float PWM_4_20MA[33] =  {
1145,
1296,
1447,
1598,
1749,
1900,
2052,
2204,
2355,
2507,
2659,
2811,
2962,
3115,
3270,
3426,
3584,
3726,
3878,
4030,
4183,
4335,
4487,
4639,
4791,
4943,
5095,
5247,
5399,
5551,
5703,
5855,
6007

};
*/
		 /*  152 ���� -1  */
	/*
const float PWM_4_20MA[33] =  {
1116,
1268,
1421,
1573,
1725,
1877,
2030,
2182,
2334,
2486,
2639,
2791,
2943,
3096,
3248,
3400,
3552,
3705,
3857,
4009,
4161,
4314,
4466,
4618,
4771,
4923,
5075,
5227,
5380,
5532,
5684,
5836,
5989
};
	  */

 		 /*  152 ���� -2   */
		 /*
const float PWM_4_20MA[33] =  {
1145,
1297,
1449,
1601,
1753,
1905,
2057,
2209,
2361,
2513,
2665,
2817,
2969,
3121,
3273,
3425,
3577,
3729,
3881,
4033,
4185,
4337,
4489,
4641,
4793,
4945,
5097,
5249,
5401,
5553,
5705,
5857,
6009
};
*/

#define NO1



#ifdef NO1

const float PPM_4_20MA[18] = {
3.76	,
4.68	,
5.64	,
6.76	,
7.88	,
8.84	,
9.88	,
10.84	,
11.88	,
12.76	,
13.72	,
14.6	,
15.56	,
16.36	,
17.32	,
18.28	,
19.4	,
20.28	

};


const float PWM_4_20MA[18] =  {
1116	,
1419	,
1723	,
2026	,
2330	,
2633	,
2937	,
3246	,
3561	,
3856	,
4160	,
4465	,
4770	,
5075	,
5379	,
5684	,
5989	,
6200	


};

#endif


#ifdef NO2

const float PPM_4_20MA[18] = {
4.01	,
5.00	,
6.01	,
7.00	,
7.99	,
9.00	,
9.98	,
10.96	,
11.91	,
12.83	,
13.74	,
14.62	,
15.50	,
16.37	,
17.21	,
18.19	,
19.30	,
20.00	


};



const float PWM_4_20MA[18] =  {
1145	,
1447	,
1749	,
2052	,
2355	,
2659	,
2962	,
3270	,
3584	,
3878	,
4183	,
4487	,
4791	,
5095	,
5399	,
5703	,
6007	,
6200	


};

#endif




void Senosr1_Gain_ADJ (void)
{
	//Senosr1_Slop_Cal( , (uint16_t)configData.outputConfig.outputReal20mA);

	Lowpwm = (uint16_t)configData.outputConfig.outputReal4mA;
	Highpwm = (uint16_t)configData.outputConfig.outputReal20mA;
	
	Senosr1Slope = (float)(((float)(Highpwm - Lowpwm)) / ((float)(High_PPm_AD - Low_PPm_AD)));
	Senosr1Offset = (float)((float)Lowpwm - (float)( Senosr1Slope * Low_PPm_AD ));


  	LowCurrentpwm = (uint16_t)configData.outputConfig.outputReal4mA;
	HighCurrentpwm = (uint16_t)configData.outputConfig.outputReal4mA;
	if(LowCurrentpwm == 0){ LowCurrentpwm = DAC_4_20MA[0]; }
	if(HighCurrentpwm == 0) { HighCurrentpwm = DAC_4_20MA[33];}  
  
	Current1Slope = (float)(((float)(High_Current - Low_Current)) / ((float)(HighCurrentpwm - LowCurrentpwm)));
	Current11Offset = (float)((float)Low_Current - (float)( Current1Slope * LowCurrentpwm ));  
}

void Senosr2_Gain_ADJ (void)
{
	Lowpwm = (uint16_t)configData.outputConfig.outputReal4mA2;
	Highpwm = (uint16_t)configData.outputConfig.outputReal20mA2;
	
	Senosr2Slope = (float)(((float)(Highpwm - Lowpwm)) / ((float)(High_NTU_AD - Low_NTU_AD)));
	Senosr2Offset = (float)((float)Lowpwm - (float)( Senosr2Slope * Low_NTU_AD ));

  	LowCurrentpwm = (uint16_t)configData.outputConfig.outputReal4mA2;
	HighCurrentpwm = (uint16_t)configData.outputConfig.outputReal4mA2;
	if(LowCurrentpwm == 0){ LowCurrentpwm = DAC_4_20MA[0]; }
	if(HighCurrentpwm == 0) { HighCurrentpwm = DAC_4_20MA[33];}  
  
	Current2Slope = (float)(((float)(High_Current - Low_Current)) / ((float)(HighCurrentpwm - LowCurrentpwm)));
	Current21Offset = (float)((float)Low_Current - (float)( Current2Slope * LowCurrentpwm ));  
}
/*
void Senosr1_Slop_Cal (uint16_t lowpwmvaule , uint16_t highpwmvaule)
{
  Lowpwm = lowpwmvaule;
	Highpwm = highpwmvaule;
	
//	if(lowpwmvaule == 0){ Lowpwm = 300; }
	if(highpwmvaule == 0) { Highpwm = DAC_4_20MA[33];}	

  if(currentData.Device_Selector_Mode&SENSOR_1_MODE)	{
	Senosr1Slope = (float)(((float)(Highpwm - Lowpwm)) / ((float)(High_PPm_AD - Low_PPm_AD)));
	Senosr1Offset = (float)((float)Lowpwm - (float)( Senosr1Slope * Low_PPm_AD ));
	}
	else if(currentData.Device_Selector_Mode&SENSOR_2_MODE)	{
	Senosr1Slope = (float)(((float)(Highpwm - Lowpwm)) / ((float)(High_NTU_AD - Low_NTU_AD)));
	Senosr1Offset = (float)((float)Lowpwm - (float)( Senosr1Slope * Low_NTU_AD ));
  }
}
*/
		/*
void Senosr1_Slop_Cal (uint16_t lowpwmvaule , uint16_t highpwmvaule)
{
	float x,y,a,b;
  Lowpwm = lowpwmvaule;
	Highpwm = highpwmvaule;
	
	


  if(currentData.Device_Selector_Mode&SENSOR_1_MODE)	{
	Senosr1Slope = (float)(((float)(Highpwm - Lowpwm)) / ((float)(High_PPm_AD - Low_PPm_AD)));
	Senosr1Offset = (float)((float)Lowpwm - (float)( Senosr1Slope * Low_PPm_AD ));
	}
	else if(currentData.Device_Selector_Mode&SENSOR_2_MODE)	{
	Senosr1Slope = (float)(((float)(Highpwm - Lowpwm)) / ((float)(High_NTU_AD - Low_NTU_AD)));
	Senosr1Offset = (float)((float)Lowpwm - (float)( Senosr1Slope * Low_NTU_AD ));
  }
}	  


void current_conversion_slop_cal(uint16_t lowpwmvaule , uint16_t highpwmvaule)
{
  	LowCurrentpwm = lowpwmvaule;
	HighCurrentpwm = highpwmvaule;
	if(lowpwmvaule == 0){ LowCurrentpwm = DAC_4_20MA[0]; }
	if(highpwmvaule == 0) { HighCurrentpwm = DAC_4_20MA[33];}  
  
	Current1Slope = (float)(((float)(High_Current - Low_Current)) / ((float)(HighCurrentpwm - LowCurrentpwm)));
	Current11Offset = (float)((float)Low_Current - (float)( Current1Slope * LowCurrentpwm ));  

}				   */

void Temperture_Slop_Cal (uint16_t lowpwmvaule , uint16_t highpwmvaule)
{
  Lowpwm = lowpwmvaule;
	Highpwm = highpwmvaule;
	
	//if(lowpwmvaule == 0){ Lowpwm = DAC_4_20MA[40]; }
	if(highpwmvaule == 0) { Highpwm = DAC_4_20MA[200]; } //5700;}	

	Temp_Slope = (float)(((float)(Highpwm - Lowpwm)) / ((float)(High_TempD - Low_TempD)));
	Temp_Offset = (float)((float)Lowpwm - (float)( Temp_Slope * Low_TempD ));
	
}

void Update_CurrentTrans (void)
{ 
	int index, i,j, k, l, data;
	float f1,f2, min, max, imsi, ppm_4_20ma;


	if(currentData.holdState == 0) {
		if(comm_run_flag == 2 && state == 0 ) {
			
			comm_run_flag = 0;
			if((compare_vaule_4mA != configData.outputConfig.outputReal4mA) || (compare_vaule_20mA != configData.outputConfig.outputReal20mA))
			{
				Senosr1_Gain_ADJ();
				compare_vaule_4mA = configData.outputConfig.outputReal4mA;
				compare_vaule_20mA = configData.outputConfig.outputReal20mA;
			}
			if((compare_vaule_4mA2 != configData.outputConfig.outputReal4mA2) || (compare_vaule_20mA2 != configData.outputConfig.outputReal20mA2))
			{
				Senosr2_Gain_ADJ();
				compare_vaule_4mA2 = configData.outputConfig.outputReal4mA2;
				compare_vaule_20mA2 = configData.outputConfig.outputReal20mA2;
			}

//			if(currentData.Device_Selector_Mode&SENSOR_1_MODE)	{
				trans_anlog_pwmVaule = (uint16_t)((Senosr1Slope*((float)currentData.S1PPM * 0.01))+Senosr1Offset);
				currentData.S1mA = (uint32_t)(((Current1Slope * (float)trans_anlog_pwmVaule)+Current11Offset)*100);
//			}
//			else if(currentData.Device_Selector_Mode&SENSOR_2_MODE)	{
				trans_anlog_pwmVaule2 = (uint16_t)((Senosr2Slope*((float)currentData.S2PPM * 0.001))+Senosr2Offset);
				currentData.S2mA = (uint32_t)(((Current2Slope * (float)trans_anlog_pwmVaule2)+Current21Offset)*100);
//			}

	//		if(currentData.Device_Selector_Mode&SENSOR_1_MODE)	{
//				trans_anlog_pwmVaule = (uint16_t)((Senosr1Slope*((float)currentData.S1PPM * 0.01))+Senosr1Offset);
//				currentData.S1mA = (uint32_t)(((Current1Slope * (float)trans_anlog_pwmVaule)+Current11Offset)*100);


/*
				if (currentData.S1PPM>200) trans_anlog_pwmVaule =DAC_4_20MA[200]; // max 
//				else trans_anlog_pwmVaule = DAC_4_20MA[currentData.S1PPM];
				else {
					if (configData.outputConfig.outputReal20mA>5000) 		
						trans_anlog_pwmVaule = DAC_4_20MA[currentData.S1PPM+(configData.outputConfig.outputReal20mA-5000) - configData.outputConfig.outputReal4mA];
					else if (configData.outputConfig.outputReal20mA<200) 	
						trans_anlog_pwmVaule = DAC_4_20MA[currentData.S1PPM+(configData.outputConfig.outputReal20mA)      - configData.outputConfig.outputReal4mA];
					else 													
						trans_anlog_pwmVaule = DAC_4_20MA[currentData.S1PPM];
				}
			//	trans_anlog_pwmVaule = *((float)trans_anlog_pwmVaule*0.01)
  */



/*				f1 = currentData.S1PPM/100.0;	// �� 100 = 1.00
				f2 = 8*f1 + 4;				 // y=8x+4
//				ppm_4_20ma = f2*100;
//				ppm_4_20ma = 315.94*f2 - 123.75;
//				ppm_4_20ma = 302.21*f2 - 72.075;
//				ppm_4_20ma = 288.12*f2 - 26.03;
				ppm_4_20ma = 2671.9*f2 - 4137.5;

				imsi = (configData.outputConfig.outputReal20mA - configData.outputConfig.outputReal4mA)
				*(ppm_4_20ma-6550.0) / (49300.0-6550.0) + configData.outputConfig.outputReal4mA;

				trans_anlog_pwmVaule = (uint16_t) imsi;
  */

/*
				f1 = currentData.S1PPM/100.0;	// �� 100 = 1.00
				f2 = 8*f1 + 4;				 // y=8x+4

			    ppm_4_20ma = f2;
				

				for (i=1;i<18;i++) {
					if (ppm_4_20ma < PPM_4_20MA[i])
					{
						min = PPM_4_20MA[i-1];
						max = PPM_4_20MA[i];

						imsi = (ppm_4_20ma-min)/(max-min);    // ������ ���ϰ� 

						min = PWM_4_20MA[i-1];
						max = PWM_4_20MA[i];
						trans_anlog_pwmVaule  = (max-min)*imsi + min; // ������ ����
					 	break;
					}
				}
*/				
				


	//			currentData.S1mA = (uint32_t)(((Current1Slope * (float)trans_anlog_pwmVaule)+Current11Offset)*100);
	//		}
  /*
			else if(currentData.Device_Selector_Mode&SENSOR_2_MODE)	{
				//trans_anlog_pwmVaule = DAC_4_20MA[currentData.S2PPM/50]; // 200���϶�
//				trans_anlog_pwmVaule = TABLE_4_20MA2[currentData.S2PPM/10];	// 1000���϶� (0~10000)
//				if (currentData.S2PPM>900) trans_anlog_pwmVaule+=40;
//				if (currentData.S2PPM>6000 && currentData.S2PPM<8100) trans_anlog_pwmVaule-=10;

				f1 = currentData.S2PPM/1000.0;	// �� 5000 =5.000
//				f2 = 1.6024*f1 + 3.976;	 	 // y=1.6024*x+3.976
				f2 = 1.6*f1 + 4.0;	 	 // y=1.6024*x+3.976

			    ppm_4_20ma = f2;

				for (i=1;i<18;i++) {
					if (ppm_4_20ma < PPM_4_20MA[i])
					{
						min = PPM_4_20MA[i-1];
						max = PPM_4_20MA[i];

						imsi = (ppm_4_20ma-min)/(max-min);    // ������ ���ϰ� 

						min = PWM_4_20MA[i-1];
						max = PWM_4_20MA[i];
						trans_anlog_pwmVaule  = (max-min)*imsi + min; // ������ ����
					 	break;
					}
				}
				currentData.S1mA = (uint32_t)(((Current1Slope * (float)trans_anlog_pwmVaule)+Current11Offset)*100);
			}
	*/


			// DAC1 output
			TIM8_Chage_Duty_Channel(2,trans_anlog_pwmVaule);

			TIM8_Chage_Duty_Channel(3,trans_anlog_pwmVaule2);

			#ifdef NEW_BOARD
//			DAC_output(1, trans_anlog_pwmVaule);
			#endif
			
			if(currentData.temperature != 0)
			{
				Temperture_Slop_Cal(0,0);
				trans_temp_pwmVaule = (uint16_t)((Temp_Slope*((float)currentData.temperature * 0.01))+Temp_Offset); 

				// DAC2 output
				TIM8_Chage_Duty_Channel(1,trans_temp_pwmVaule);
				#ifdef NEW_BOARD
				//DAC_output(2, trans_temp_pwmVaule);
				#endif
			}
		}
	}
	else {
		TIM8_Chage_Duty_Channel(2,0);
		TIM8_Chage_Duty_Channel(3,0);
	}
}

	   
void TIM8_Chage_Duty_Channel(uint16_t channel , uint16_t Duty)
{ 
	 
		switch (channel)
  	 {
        case 1 :
					      TIM8->CCR1 = Duty;  
				      break;
				case 2 :
					      TIM8->CCR2 = Duty;   
					    break;
				case 3 :
					      TIM8->CCR3 = Duty;   
					    break;
				case 4 :
					      TIM8->CCR4 = Duty;
					    break;
				default:
					    break;				
     }
}
