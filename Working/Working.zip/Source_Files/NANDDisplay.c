#include "NANDDisplay.h"


#define TITLE_Y_START	0
#define TITLE_Y_END		40

#define VIEW_Y_START	50
#define VIEW_Y_END		210

#define BOTTOM_Y_START	220
#define BOTTOM_Y_END	255


//uint8_t imageBuffer[43200] = { 0 , };
//uint8_t imageBuffer[48000] = {0,};
uint8_t imageBuffer[40960] = {0,};

uint16_t* GlobalMemory;

/*void DrawTextETC(uint32_t x, uint32_t y, uint32_t image, uint32_t draw) {
    const uint32_t imageData[13][3] = {
        {0, 70, 30},
        {2100, 40, 30},
        {3300, 70, 30},
        {5400, 40, 30},
        {6600, 40, 30},
        {7800, 70, 30},
        {9900, 70, 30},
        {12000, 70, 30},
        {14100, 70, 30},
        {16200, 70, 30},
        {18300, 70, 30},
        {20400, 70, 30},
        {985, 250, 60}};

    if (image > TEXT_ETC_F_RESET_MESSAGE)
        return;

    NAND_ReadTextETC(image);
    if (draw == DRAW_IMAGE_ENABLE)
        TFT_DrawImage(x, y, x + imageData[image][1], y + imageData[image][2], &GlobalMemory[imageData[image][0]], DRAW_REVERSE);
    else
        TFT_Fill(x, y, x + imageData[image][1], y + imageData[image][2], WHITE);
} 

void DrawTextsize260(uint32_t x, uint32_t y, uint32_t image, uint32_t draw) {
    uint32_t imageStartAddr = 0;
    if (image > TEXT260_S2_PRIME_ING_Y)
        return;

    if (draw == DRAW_IMAGE_ENABLE) {
        NAND_ReadTextsize260(image);
        imageStartAddr = image * 7800;
        imageStartAddr = imageStartAddr % 1024;
        TFT_DrawImage(x, y, x + 260, y + 30, &GlobalMemory[imageStartAddr], DRAW_REVERSE);
    } else
        TFT_Fill(x, y, x + 260, y + 30, WHITE);
}
  
void DrawTextsize180(uint32_t x, uint32_t y, uint32_t image, uint32_t draw) {
    uint32_t imageStartAddr = 0;
    if (image > TEXT180_S1_Current_Measure)
        return;

    if (draw == DRAW_IMAGE_ENABLE) {
        NAND_ReadTextsize180(image);
        imageStartAddr = image * 5400;
        imageStartAddr = imageStartAddr % 1024;
        TFT_DrawImage(x, y, x + 180, y + 30, &GlobalMemory[imageStartAddr], DRAW_REVERSE);
    } else
        TFT_Fill(x, y, x + 180, y + 30, WHITE);
}

void DrawTextsize120(uint32_t x, uint32_t y, uint32_t image, uint32_t draw) {
    uint32_t imageStartAddr = 0;
    if (image > TEXT120_ZERO_ALARM)
        return;

    if (draw == DRAW_IMAGE_ENABLE) {
        NAND_ReadTextsize120(image);
        imageStartAddr = image * 3600;
        imageStartAddr = imageStartAddr % 1024;
        TFT_DrawImage(x, y, x + 120, y + 30, &GlobalMemory[imageStartAddr], DRAW_REVERSE);
    } else
        TFT_Fill(x, y, x + 120, y + 30, WHITE);
}

void DrawTextsize96(uint32_t x, uint32_t y, uint32_t image, uint32_t draw) {
    uint32_t imageStartAddr = 0;
    //if(image > TEXT96_FILTER)
    //if(image > TEXT96_CI3)
    if (image > TEXT96_MANUAL_OPERATION)
        return;

    if (image == 0) {
        image = 0;
    }

    if (draw == DRAW_IMAGE_ENABLE) {
        NAND_ReadTextsize96(image);
        imageStartAddr = image * 2880;
        imageStartAddr = imageStartAddr % 1024;
        TFT_DrawImage(x, y, x + 96, y + 30, &GlobalMemory[imageStartAddr], DRAW_REVERSE);
    } else
        TFT_Fill(x, y, x + 96, y + 30, WHITE);
}

void DrawTextsize55(uint32_t x, uint32_t y, uint32_t image, uint32_t draw) {
    if (image > TEXT55_CYCLE)
        return;

    if (draw == DRAW_IMAGE_ENABLE) {
        NAND_ReadTextsize55();
        TFT_DrawImage(x, y, x + 55, y + 30, &GlobalMemory[1650 * image], DRAW_REVERSE);

    } else
        TFT_Fill(x, y, x + 55, y + 30, WHITE);
}
  
void DrawUnit(uint32_t x, uint32_t y, uint32_t image, uint32_t draw) {
    if (image > UNIT_SEC)
        return;

    if (draw == DRAW_IMAGE_ENABLE) {
        NAND_ReadUnit();
        TFT_DrawImage(x, y, x + 30, y + 30, &GlobalMemory[900 * image], DRAW_REVERSE);
    } else
        TFT_Fill(x, y, x + 30, y + 30, WHITE);
}
  */


void DrawIcon(uint32_t icon, uint32_t draw) {
    //	const uint16_t axis[4][3] = {{1,1,0},{390,1,1600},{435,1,3200},{70,110,4800}};
    const uint16_t axis[6][3] = {
        {1, 4, 4680},		// CI
        {405, 4, 1600},		// BELL
        {440, 4, 2500},		// SDCARD
        {403, 55, 3400},	// CAUTION
        {1, 4, 4680},		// WORKING
        {185, 55, 3400}};	// CAUTION1

    if (icon > ICON_CAUTION1)
        return;

    if (draw == DRAW_IMAGE_ENABLE) {
        NAND_ReadICON();
        //		TFT_DrawImage(axis[icon][0], axis[icon][1], axis[icon][0]+40, axis[icon][1]+40, &GlobalMemory[axis[icon][2]], DRAW_REVERSE);
        switch (icon) {
            case ICON_CI:
                TFT_DrawImage(axis[icon][0], axis[icon][1], axis[icon][0] + 35, axis[icon][1] + 30, &GlobalMemory[axis[icon][2]], DRAW_NORMAL);
                break;
            case ICON_BELL:
                TFT_DrawImage(axis[icon][0], axis[icon][1], axis[icon][0] + 30, axis[icon][1] + 30, &GlobalMemory[axis[icon][2]], DRAW_NORMAL);
                break;
            case ICON_SDCARD:
                TFT_DrawImage(axis[icon][0], axis[icon][1], axis[icon][0] + 30, axis[icon][1] + 30, &GlobalMemory[axis[icon][2]], DRAW_NORMAL);
                break;
            case ICON_CAUTION:
                TFT_DrawImage(axis[icon][0], axis[icon][1], axis[icon][0] + 40, axis[icon][1] + 32, &GlobalMemory[axis[icon][2]], DRAW_NORMAL);
                break;
            case ICON_WORKING:
                TFT_DrawImage(axis[icon][0], axis[icon][1], axis[icon][0] + 35, axis[icon][1] + 30, &GlobalMemory[axis[icon][2]], DRAW_NORMAL);
                break;
            case ICON_CAUTION1:
                TFT_DrawImage(axis[icon][0], axis[icon][1], axis[icon][0] + 40, axis[icon][1] + 32, &GlobalMemory[axis[icon][2]], DRAW_NORMAL);
                break;
        };

    } else {
        //		TFT_Fill(axis[icon][0], axis[icon][1], axis[icon][0]+40, axis[icon][1]+32, WHITE);

        switch (icon) {
            case ICON_CI:
                TFT_Fill(axis[icon][0], axis[icon][1], axis[icon][0] + 35, axis[icon][1] + 30, WHITE);
                break;
            case ICON_BELL:
                TFT_Fill(axis[icon][0], axis[icon][1], axis[icon][0] + 30, axis[icon][1] + 30, WHITE);
                break;
            case ICON_SDCARD:
                TFT_Fill(axis[icon][0], axis[icon][1], axis[icon][0] + 30, axis[icon][1] + 30, WHITE);
                break;
            case ICON_CAUTION:
                TFT_Fill(axis[icon][0], axis[icon][1], axis[icon][0] + 40, axis[icon][1] + 32, WHITE);
                break;
            case ICON_WORKING:
                TFT_Fill(axis[icon][0], axis[icon][1], axis[icon][0] + 35, axis[icon][1] + 30, WHITE);
                break;
            case ICON_CAUTION1:
                TFT_Fill(axis[icon][0], axis[icon][1], axis[icon][0] + 40, axis[icon][1] + 32, WHITE);
                break;
        };
    }
}



//================================================


void DrawSmallNumber0(uint32_t x, uint32_t y, char* str, uint16_t color) {
    uint32_t i = 0;
    NAND_ReadSNumber();
    while (str[i] != 0) {
        if (str[i] > 0x2F && str[i] < 0x3A)
            TFT_DrawImageSmall(x, y, x + 15, y + 17, (uint16_t*)&(imageBuffer[(str[i] - 0x30) * 15 * 17 * 2]), color);
        else if (str[i] == ' ')
            TFT_DrawImageSmall(x, y, x + 15, y + 17, (uint16_t*)&(imageBuffer[13 * 15 * 17 * 2]), color);
        else if (str[i] == '-')
            TFT_DrawImageSmall(x, y, x + 15, y + 17, (uint16_t*)&(imageBuffer[10 * 15 * 17 * 2]), color);
        else if (str[i] == ':')
            TFT_DrawImageSmall(x, y, x + 15, y + 17, (uint16_t*)&(imageBuffer[11 * 15 * 17 * 2]), color);
        else if (str[i] == '.')
            TFT_DrawImageSmall(x, y, x + 15, y + 17, (uint16_t*)&(imageBuffer[12 * 15 * 17 * 2]), color);
        else if (str[i] == 'C')
            TFT_DrawImageSmall(x, y, x + 15, y + 17, (uint16_t*)&(imageBuffer[14 * 15 * 17 * 2]), color); // �µ� ǥ�� �߰�����.
        else
            return;
        x += 14; // 15
        ++i;
    }
}

void DrawMediumNumber0(uint32_t x, uint32_t y, char* str, uint16_t color) {
    uint32_t i = 0;
    uint16_t* buffer;

    if (color == YELLOW) {
        NAND_ReadMNumberY();
        buffer = (uint16_t*) YellowMinus;
    } else {
        NAND_ReadMNumberW();
        buffer = (uint16_t*) WhiteMinus;
    }
    while (str[i] != 0) {
        if (str[i] > 0x2F && str[i] < 0x3A)
            TFT_DrawImage(x, y, x + 22, y + 26, (uint16_t*)&(imageBuffer[(str[i] - 0x30) * 22 * 26 * 2]), DRAW_REVERSE);
        else if (str[i] == '.')
            TFT_DrawImage(x, y, x + 22, y + 26, (uint16_t*)&(imageBuffer[10 * 22 * 26 * 2]), DRAW_REVERSE);
        else if (str[i] == ' ')
            TFT_DrawImage(x, y, x + 22, y + 26, (uint16_t*)&(imageBuffer[11 * 22 * 26 * 2]), DRAW_REVERSE);
        else if (str[i] == '-')
            TFT_DrawImage(x, y, x + 22, y + 26, (uint16_t*) (buffer), DRAW_REVERSE);
        else
            return;
        x += 22;
        ++i;
    }
}

void DrawLargeNumber0(uint32_t x, uint32_t y, char* str) {
    uint32_t i = 0;
    NAND_ReadLNumber();
    while (str[i] != 0) {
        if (str[i] > 0x2F && str[i] < 0x3A)
            TFT_DrawImage(x, y, x + 36, y + 47, (uint16_t*)&(imageBuffer[(str[i] - 0x30) * 36 * 47 * 2]), DRAW_REVERSE);
        else if (str[i] == '.')
            TFT_DrawImage(x, y, x + 36, y + 47, (uint16_t*)&(imageBuffer[10 * 36 * 47 * 2]), DRAW_REVERSE);
        else if (str[i] == ' ')
            TFT_DrawImage(x, y, x + 36, y + 47, (uint16_t*)&(imageBuffer[11 * 36 * 47 * 2]), DRAW_REVERSE);
        else
            return;
        x += 36;
        ++i;
    }
}

//==========================================


void DrawLineRectangle(uint32_t x, uint32_t y, uint32_t xEnd, uint32_t yEnd, uint16_t color) {
    if (yEnd < 2 || xEnd < 2)
        return;

    TFT_Fill(x, y, xEnd, y + 1, color);
    TFT_Fill(x, y, x + 1, yEnd, color);
    TFT_Fill(xEnd - 1, y, xEnd, yEnd, color);
    TFT_Fill(x, yEnd - 1, xEnd, yEnd, color);
}

// �Ʒ��� ���� ���� ���� 

void DrawBottomLine(void) {
    TFT_Fill(169, 235, 171, 272, BROWN);
    TFT_Fill(309, 235, 311, 272, BROWN);
}



//=====================================
#include "back_corner.h"
#include "back_corner2.h"


// TITLE �� ��ü 

void ClearTitleArea(void) {
    TFT_Fill(0, 0, 480, TITLE_Y_END, WHITE);
}

// TITLE �� ��� 

void ClearTitle(void) {
    //	TFT_Fill(110, 0, 290, TITLE_Y_END, WHITE);
    TFT_Fill(90, 0, 330, TITLE_Y_END, WHITE);
}




// VIEW  ���


// �⺻ ���
// ���κп� ���
// �Ʒ� �κп� �޴����� 
#ifdef CH2

void ClearViewArea(void) {
    TFT_Fill(0, VIEW_Y_START, 480, VIEW_Y_END, WHITE);

    TFT_Fill(0, TITLE_Y_END, 20, 272, BACK_COLOR);
    TFT_Fill(0, TITLE_Y_END, 480, 50, BACK_COLOR);
    TFT_Fill(460, TITLE_Y_END, 480, 272, BACK_COLOR);
    TFT_Fill(0, 208, 480, 272, BACK_COLOR);


    TFT_Fill(223+17, TITLE_Y_END, 253, 272, BACK_COLOR);

    TFT_DrawImage(19,  50,  19 + 17,  50 + 17, (uint16_t *) IMG_back_corner, DRAW_NORMAL);
    TFT_DrawImage(223, 50, 223 + 17,  50 + 17, (uint16_t *) IMG_back_corner, DRAW_RIGHT_TOP);
    TFT_DrawImage(19, 191,  19 + 17, 191 + 17, (uint16_t *) IMG_back_corner, DRAW_LEFT_BOTTOM);
    TFT_DrawImage(223, 191,223 + 17, 191 + 17, (uint16_t *) IMG_back_corner, DRAW_RIGHT_BOTTOM);

    TFT_DrawImage(253,  50, 253 + 17,  50 + 17, (uint16_t *) IMG_back_corner, DRAW_NORMAL);
    TFT_DrawImage(253, 191, 253 + 17, 191 + 17, (uint16_t *) IMG_back_corner, DRAW_LEFT_BOTTOM);

    TFT_DrawImage(443, 50,  443 + 17,  50 + 17, (uint16_t *) IMG_back_corner, DRAW_RIGHT_TOP);
    TFT_DrawImage(443, 191, 443 + 17, 191 + 17, (uint16_t *) IMG_back_corner, DRAW_RIGHT_BOTTOM);
}

#else

void ClearViewArea(void) {
    TFT_Fill(0, VIEW_Y_START, 480, VIEW_Y_END, WHITE);

    TFT_Fill(0, TITLE_Y_END, 20, 272, BACK_COLOR);
    TFT_Fill(0, TITLE_Y_END, 480, 50, BACK_COLOR);
    TFT_Fill(460, TITLE_Y_END, 480, 272, BACK_COLOR);
    TFT_Fill(0, 208, 480, 272, BACK_COLOR);

    TFT_DrawImage(19, 50, 19 + 17, 50 + 17, (uint16_t *) IMG_back_corner, DRAW_NORMAL);
    TFT_DrawImage(443, 50, 443 + 17, 50 + 17, (uint16_t *) IMG_back_corner, DRAW_RIGHT_TOP);
    TFT_DrawImage(19, 191, 19 + 17, 191 + 17, (uint16_t *) IMG_back_corner, DRAW_LEFT_BOTTOM);
    TFT_DrawImage(443, 191, 443 + 17, 191 + 17, (uint16_t *) IMG_back_corner, DRAW_RIGHT_BOTTOM);
}

#endif


// BOTTOM  �Ʒ���

void ClearBottomArea(void) {
    TFT_Fill(0, BOTTOM_Y_START, 480, 272, BACK_COLOR);
}

//=======================================

void DrawBack1(void) {
    TFT_Fill(0, 0, 480, 272, WHITE);

    ClearViewArea();
}

//=======================================

// ���κп� ������� - ����
// �Ʒ� �κ� ��ü ����
void ClearViewArea2(void) {
    TFT_Fill(0, VIEW_Y_START, 480, 272, WHITE);
    TFT_Fill(0, VIEW_Y_START, 480, 117, BACK_COLOR2);

    TFT_Fill(0, TITLE_Y_END, 20, 272, BACK_COLOR);
    TFT_Fill(0, TITLE_Y_END, 480, 50, BACK_COLOR);
    TFT_Fill(460, TITLE_Y_END, 480, 272, BACK_COLOR);
    TFT_Fill(0, 257, 480, 272, BACK_COLOR);

    TFT_DrawImage(19, 50, 19 + 17, 50 + 17, (uint16_t *) IMG_back_corner2, DRAW_NORMAL);
    TFT_DrawImage(443, 50, 443 + 17, 50 + 17, (uint16_t *) IMG_back_corner2, DRAW_RIGHT_TOP);
    TFT_DrawImage(19, 240, 19 + 17, 240 + 17, (uint16_t *) IMG_back_corner, DRAW_LEFT_BOTTOM);
    TFT_DrawImage(443, 240, 443 + 17, 240 + 17, (uint16_t *) IMG_back_corner, DRAW_RIGHT_BOTTOM);
}


// ���κп� ������� - ����
// �Ʒ��κп� �޴�����
void ClearViewArea3(void) {
    TFT_Fill(0, VIEW_Y_START, 480, 272, WHITE);
    TFT_Fill(0, VIEW_Y_START, 480, 117, BACK_COLOR2);

    TFT_Fill(0, TITLE_Y_END, 20, 272, BACK_COLOR);
    TFT_Fill(0, TITLE_Y_END, 480, 50, BACK_COLOR);
    TFT_Fill(460, TITLE_Y_END, 480, 272, BACK_COLOR);
    TFT_Fill(0, 208, 480, 272, BACK_COLOR);

    TFT_DrawImage(19, 50, 19 + 17, 50 + 17, (uint16_t *) IMG_back_corner2, DRAW_NORMAL);
    TFT_DrawImage(443, 50, 443 + 17, 50 + 17, (uint16_t *) IMG_back_corner2, DRAW_RIGHT_TOP);
    TFT_DrawImage(19, 191, 19 + 17, 191 + 17, (uint16_t *) IMG_back_corner, DRAW_LEFT_BOTTOM);
    TFT_DrawImage(443, 191, 443 + 17, 191 + 17, (uint16_t *) IMG_back_corner, DRAW_RIGHT_BOTTOM);
}


// �����̷¿� �����
// ���κ� ������
// �Ʒ��κ� ��ü ����
void ClearViewArea4(void) {
    TFT_Fill(0, VIEW_Y_START, 480, 272, WHITE);
    TFT_Fill(0, VIEW_Y_START, 480, 117, WHITE);

    TFT_Fill(0, TITLE_Y_END, 20, 272, BACK_COLOR);
    TFT_Fill(0, TITLE_Y_END, 480, 50, BACK_COLOR);
    TFT_Fill(460, TITLE_Y_END, 480, 272, BACK_COLOR);
    TFT_Fill(0, 257, 480, 272, BACK_COLOR);

    TFT_DrawImage(19, 50, 19 + 17, 50 + 17, (uint16_t *) IMG_back_corner, DRAW_NORMAL);
    TFT_DrawImage(443, 50, 443 + 17, 50 + 17, (uint16_t *) IMG_back_corner, DRAW_RIGHT_TOP);
    TFT_DrawImage(19, 240, 19 + 17, 240 + 17, (uint16_t *) IMG_back_corner, DRAW_LEFT_BOTTOM);
    TFT_DrawImage(443, 240, 443 + 17, 240 + 17, (uint16_t *) IMG_back_corner, DRAW_RIGHT_BOTTOM);
}




void DrawBack2(void) {
    TFT_Fill(0, 0, 480, 272, WHITE);

    ClearViewArea2();
}




